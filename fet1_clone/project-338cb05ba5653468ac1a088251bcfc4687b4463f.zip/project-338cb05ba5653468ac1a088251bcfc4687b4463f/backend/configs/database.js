const mongoose = require('mongoose')
let db = 'mongodb://localhost:27017/swkproject'
mongoose.connect(db, {
    useUnifiedTopology: true, useNewUrlParser: true
}).then(() =>
    console.log('DB Connected!')
).catch(err => {
    console.log(`DB Connection Error: ${err.message}`)
})
module.exports = mongoose
