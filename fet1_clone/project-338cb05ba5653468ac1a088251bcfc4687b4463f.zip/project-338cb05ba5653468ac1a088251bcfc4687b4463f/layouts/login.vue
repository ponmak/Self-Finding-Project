<template>
<v-main class="bg-templat">
    <v-container>
        <Nuxt />
    </v-container>
</v-main>
</template>

  
  
<script>
export default {
    name: 'login',
    data() {
        return {

        }
    }
}
</script>

<style scoped>
.bg-templat {
    background: #e98989;;
    min-height: 970px;
}
</style>
